/* Pavithra Vinay

Create below tables: */


/* FamilyPackage */
  
CREATE TABLE FamilyPackage(
id INT NOT NULL PRIMARY KEY,
address VARCHAR(50) NOT NULL,
phone VARCHAR(15) NOT NULL UNIQUE
);


/* RecCenterMember */

CREATE TABLE RecCenterMember(
id INT NOT NULL PRIMARY KEY,
f_name VARCHAR(20) NOT NULL,
l_name VARCHAR(20) NOT NULL,
dob DATE NOT NULL,
family_id INT,
FOREIGN KEY(family_id) REFERENCES FamilyPackage(id)
);


/* Type */

CREATE TABLE Type(
type VARCHAR(20)NOT NULL PRIMARY KEY,
description VARCHAR(100) NOT NULL
);



/* Instructor */

CREATE TABLE Instructor(
id INT NOT NULL PRIMARY KEY,
f_name VARCHAR(20) NOT NULL,
l_name VARCHAR(20) NOT NULL,
member_id INT, 
FOREIGN KEY(member_id) REFERENCES RecCenterMember(id)
);


/* Class */

CREATE TABLE Class(
id INT NOT NULL PRIMARY KEY,
title VARCHAR(30) NOT NULL,
type VARCHAR(15) NOT NULL, 
instructor INT NOT NULL, 
season VARCHAR(10) NOT NULL,
year INT NOT NULL,
FOREIGN KEY(type) REFERENCES TYPE(type),
FOREIGN KEY(instructor) REFERENCES Instructor(id),
CONSTRAINT chk_season CHECK(season IN ('Spring', 'Summer', 'Fall', 'Winter'))
);



/* Enrollment */

CREATE TABLE Enrollment(
class_id INT NOT NULL, 
member_id INT NOT NULL,
cost INT NOT NULL,
PRIMARY KEY(class_id,member_id),
FOREIGN KEY(class_id) REFERENCES Class(id),
FOREIGN KEY(member_id) REFERENCES RecCenterMember(id) 
);