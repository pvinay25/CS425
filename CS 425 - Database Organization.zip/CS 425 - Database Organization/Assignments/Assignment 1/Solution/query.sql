/* Pavithra Vinay */

/* Question #2: */

SELECT DISTINCT phone 
FROM FAMILYPACKAGE F, RECCENTERMEMBER R
WHERE F.id = R.FAMILY_ID and R.L_NAME = 'O''Shea';


/* Question #3: */

SELECT I.f_name, I.l_name, C.TITLE
FROM INSTRUCTOR I, CLASS C
WHERE I.ID = C.INSTRUCTOR;


/* Question #4: */

SELECT DISTINCT R.f_name, R.l_name 
FROM RECCENTERMEMBER R, FAMILYPACKAGE F
WHERE R.FAMILY_ID IS NULL;


/*Question #5: */

SELECT DISTINCT R.f_name, R.l_name
FROM RECCENTERMEMBER R, CLASS C,INSTRUCTOR I
WHERE I.MEMBER_ID = R.ID and C.INSTRUCTOR = I.ID and (C.TYPE = 'Art' OR C.TYPE = 'Craft' );


/* Question #6: */

(SELECT R.f_name, R.l_name
FROM RECCENTERMEMBER R)
MINUS 
(SELECT R.f_name, R.l_name 
From Class C1 
INNER JOIN ENROLLMENT E 
ON C1.id = E.class_id 
INNER JOIN RECCENTERMEMBER R 
ON R.ID = E.MEMBER_ID
Where (C1.SEASON <> 'Spring' and C1.YEAR = 2009) OR C1.year >=2010);




/* Question #7: */

SELECT DISTINCT I.f_name, I.l_name, T.description
From CLASS C
INNER JOIN
((SELECT C1.instructor 
From Class C1 
WHERE C1.SEASON = 'Spring' and C1.YEAR = 2009)
INTERSECT
(SELECT C1.instructor 
From Class C1 
WHERE C1.SEASON = 'Fall' and C1.YEAR = 2009)) Temp
ON C.instructor = temp.instructor
INNER JOIN INSTRUCTOR I
ON C.INSTRUCTOR = I.ID
INNER JOIN Type T
on C.type = T.type;




/* Question #8: */

SELECT T.type, T.description
FROM Type T,
((SELECT C.type 
FROM CLASS C
WHERE C.YEAR = 2008)
INTERSECT
(SELECT C.type 
FROM CLASS C
WHERE C.YEAR = 2009)) R1
WHERE T.type = R1.type;



