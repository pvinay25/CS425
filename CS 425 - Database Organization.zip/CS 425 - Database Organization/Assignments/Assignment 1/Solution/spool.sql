/* Question#2 */

PHONE         
---------------
312-555-9403   




/* Question #3 */

F_NAME               L_NAME               TITLE                        
-------------------- -------------------- ------------------------------
Annie                Heard                Team games                    
Annie                Heard                Yoga (Adv.)                   
Annie                Heard                Chinese (Intro.)              
Annie                Heard                Photography                   
Monica               Knapp                Yoga (Intro.)                 
Monica               Knapp                Needle points                 
James                Robertson            Chinese (Intro.)              
James                Robertson            Oil painting                  
April                O'Shea               Woodworking                   
April                O'Shea               Origami (Adv.)                

 10 rows selected 




/* Question #4 */


F_NAME               L_NAME             
-------------------- --------------------
Cassandra            McDonald            
Leslie               Blackburn           
Emily                Citrin              
Vijay                Gupta               
Lisa                 Brown               
Harry                Smith               
Laura                Dickinson           
Sandra               Svoboda             

 8 rows selected 




/* Question #5 */


F_NAME               L_NAME             
-------------------- --------------------
Monica               Knapp               
Mike                 O'Shea              




/*Question #6 */


F_NAME               L_NAME             
-------------------- --------------------
April                O'Shea              
Cassandra            McDonald            
Cassie               O'Shea              
Dongmei              Tang                
Harry                Smith               
Jessie               Knapp               
Justin               Smith               
Leslie               Blackburn           
Lisa                 Brown               
Lisa                 Tang                
Monica               Knapp               

F_NAME               L_NAME             
-------------------- --------------------
Sandra               Svoboda             
Victor               Garcia              
Vijay                Gupta               

 14 rows selected 





/* Question #7 */

F_NAME               L_NAME
-------------------- --------------------
DESCRIPTION                                                                    
--------------------------------------------------------------------------------
April                O'Shea               
Knitting, sewing, etc                                                           




/* Question #8 */

TYPE
--------------------
DESCRIPTION
--------------------------------------------------------------------------------
Art                  
Paining, sculpting, etc                                                         

Exercise             
Any courses having to do with physical activity                                 

Languages            
Anything to do with writing, literature, or communication                       


