/* Commands to drop tables */
drop table user_ CASCADE Constraints;

drop table Student CASCADE Constraints;

drop table TA CASCADE Constraints;

drop table MODERATOR_ADMINISTRATOR CASCADE Constraints;

drop table Faculty CASCADE Constraints;

drop table Course CASCADE Constraints;

drop table InterestGroup_Club CASCADE Constraints;

drop table CourseInterestGroup CASCADE Constraints;

drop table DiscussionForum CASCADE Constraints;

drop table Enrolled CASCADE Constraints;

drop table Assists CASCADE Constraints;

drop table Assigns CASCADE Constraints;

drop table Approves CASCADE Constraints;

drop table Teaches CASCADE Constraints;

drop table course_has CASCADE Constraints;

drop table Joins CASCADE Constraints;

drop table Creates CASCADE Constraints;

drop table CourseInterestGroup_has CASCADE Constraints;

drop table InterestGroupClub_has CASCADE Constraints;

drop table joinsCIG CASCADE Constraints;

drop table Topic CASCADE Constraints;

drop table Comments CASCADE Constraints;

DROP TABLE ALERT CASCADE Constraints;

DROP TABLE MODERATESCIG CASCADE Constraints;

DROP TABLE MODERATESIGC CASCADE Constraints;

DROP TABLE CRITERIA;



Create Table User_(
userId INT PRIMARY KEY,
email varchar(40),
name varchar(40),
username varchar(40),
password varchar(50)
);

Create table Student(
studentId INT,
year INTEGER,
semester VARCHAR(10),
GPA REAL,
degreeStatus VARCHAR(40),
degreeType VARCHAR(40),
jobs varchar(100),
bonusCredit INTEGER,
numOfCourses INTEGER,
showGPA CHAR(1),
showGroupClub CHAR(1),
showCourseInterestGroup CHAR(1),
FOREIGN KEY(studentId) REFERENCES User_(userId)
);

CREATE TABLE TA(
TAId INT,
FOREIGN KEY(TAId) REFERENCES USER_(userId)
);


CREATE TABLE Faculty(
facultyId INT,
year INT,
position VARCHAR(40),
experience VARCHAR(200),
projects VARCHAR(200),
FOREIGN KEY(facultyID) REFERENCES User_(userId)
);

CREATE TABLE Course(
Id INT PRIMARY KEY,
title VARCHAR (40)
);

Create table InterestGroup_Club(
groupClubId INT PRIMARY KEY,
name VARCHAR(40), 
type VARCHAR(40),
description VARCHAR(200)
);


CREATE TABLE CourseInterestGroup(
groupId INT PRIMARY KEY,
name VARCHAR(100)
);


CREATE TABLE DiscussionForum(
forumID INT PRIMARY KEY,
forumName VARCHAR(100),
createdBy INT,
FOREIGN KEY(createdBy) REFERENCES User_(userID)
);


CREATE TABLE Enrolled(
studentId INT,
courseId INT,
grade CHAR(1),
PRIMARY KEY(studentId ,courseId),
FOREIGN KEY(studentId) REFERENCES User_(userId),
FOREIGN KEY(courseId) REFERENCES Course(Id)
);

CREATE TABLE  Assists(
TAId INT,
courseId INT,
PRIMARY KEY(TAId ,courseId)
);


CREATE TABLE  ModeratesCIG(
modId INT,
groupId INT,
PRIMARY KEY(modId ,groupId),
FOREIGN KEY(modId) REFERENCES User_(userId),
FOREIGN KEY(groupId) REFERENCES CourseInterestGroup(groupId)
);

CREATE TABLE  ModeratesIGC(
modId INT,
groupClubId INT,
PRIMARY KEY(modId ,groupClubId),
FOREIGN KEY(modId) REFERENCES User_(userId),
FOREIGN KEY(groupClubId) REFERENCES InterestGroup_Club(groupClubID)
);

CREATE TABLE Alert(
moderatorId INTEGER REFERENCES User_(userId),
alert VARCHAR(300),
alertTime TIMESTAMP PRIMARY KEY,
forumId INTEGER REFERENCES DiscussionForum(forumId)
);


CREATE TABLE  Assigns(
moderator_uId INT,
administrator_uId INT,
FOREIGN KEY(moderator_uId) REFERENCES User_(userId),
FOREIGN KEY(administrator_uId) REFERENCES User_(userId)
);


CREATE TABLE Approves(
approverId INT,
approvedGroupClubId INT,
FOREIGN KEY(approverId ) REFERENCES User_(userID),
FOREIGN KEY(approvedGroupClubId) REFERENCES InterestGroup_Club(groupClubId)
);


CREATE TABLE Teaches (
facultyId INT,
courseId INT,
groupId INT,
avgGPA REAL,
PRIMARY KEY(facultyId,courseId),
FOREIGN KEY(facultyId) REFERENCES User_(userId)
);


CREATE TABLE course_has (
courseId INT,
groupId INT,
PRIMARY KEY(courseId,groupId),
FOREIGN KEY(courseId) REFERENCES Course(Id), 
FOREIGN KEY(groupId) REFERENCES CourseInterestGroup(groupId)
);


CREATE TABLE Joins(
memberId INT,
groupClubId INT,
username VARCHAR(50),
password VARCHAR(50),
PRIMARY KEY(memberId,groupClubId), 
FOREIGN KEY(memberId) REFERENCES User_(userId),
FOREIGN KEY(groupClubId) REFERENCES InterestGroup_Club(groupClubId)
);


CREATE TABLE Creates(
CreatedBy INT,
groupClubId INT,
forumID INT,
PRIMARY KEY(createdBy ,groupClubId,ForumId),
FOREIGN KEY(createdBy) REFERENCES User_(userId),
FOREIGN KEY(groupClubId) REFERENCES InterestGroup_Club(groupClubId),
FOREIGN KEY(forumId) REFERENCES DiscussionForum(forumID)
);


CREATE TABLE CourseInterestGroup_has(
forumID INT,
groupId INT,
PRIMARY KEY(forumID, groupId),
FOREIGN KEY(forumId) REFERENCES DiscussionForum(forumID),
FOREIGN KEY(groupId) REFERENCES CourseInterestGroup(groupId)
);


CREATE TABLE InterestGroupClub_has (
forumID INT,
groupClubId INT,
PRIMARY KEY(groupClubId, forumID),
FOREIGN KEY(groupClubId) REFERENCES InterestGroup_Club(groupClubId),
FOREIGN KEY(forumID) REFERENCES DiscussionForum(forumID)
);


CREATE TABLE joinsCIG(
memberID INT,
groupId INT,
username VARCHAR(30),
password VARCHAR(30),
PRIMARY KEY(memberId,groupId),
FOREIGN KEY(memberId) REFERENCES User_(userId),
FOREIGN KEY(groupId) REFERENCES courseInterestGroup(groupId)
);


CREATE TABLE Topic(
topicID INT PRIMARY KEY,
topicName VARCHAR(100),
forumID INT,
FOREIGN KEY(forumID) REFERENCES DiscussionForum(forumID)
);


CREATE TABLE Comments(
commentID INT PRIMARY KEY,
commentedBy INT,
topicID INT,
comments VARCHAR(500),
FOREIGN KEY(commentedBy) REFERENCES User_(userID),
FOREIGN KEY(topicID) REFERENCES topic(topicID)
);



CREATE TABLE CRITERIA(
CriteriaNumber NUMBER PRIMARY KEY,
Action VARCHAR2(100) ,
Description VARCHAR2(200), 
Points NUMBER
);

COMMIT;





















